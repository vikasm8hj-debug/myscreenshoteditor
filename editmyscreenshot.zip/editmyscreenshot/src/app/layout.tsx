import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import { AuthProvider } from "@/context/AuthContext";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "myscreenshoteditor \u2013 Edit Text Inside Screenshots Online",
  description: "myscreenshoteditor is an AI powered tool that lets you detect and edit text inside screenshots instantly.",
  openGraph: {
    title: "myscreenshoteditor \u2013 Edit Text Inside Screenshots Online",
    description: "myscreenshoteditor is an AI powered tool that lets you detect and edit text inside screenshots instantly.",
    siteName: "myscreenshoteditor",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "myscreenshoteditor \u2013 Edit Text Inside Screenshots Online",
    description: "myscreenshoteditor is an AI powered tool that lets you detect and edit text inside screenshots instantly.",
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'myscreenshoteditor',
    description: 'myscreenshoteditor is an AI powered tool that lets you detect and edit text inside screenshots instantly.',
    applicationCategory: 'MultimediaApplication',
    operatingSystem: 'All'
  };

  return (
    <html lang="en" className="light sm:scroll-smooth">
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body className={`${inter.variable} antialiased min-h-screen bg-background text-foreground flex flex-col selection:bg-primary/20 selection:text-primary`}>
        <AuthProvider>
          <Navbar />
          <main className="flex-1 flex flex-col">{children}</main>
        </AuthProvider>
      </body>
    </html>
  );
}

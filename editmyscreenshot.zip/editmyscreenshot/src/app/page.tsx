"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { 
  UploadCloud, Type, Wand2, Layers, 
  Zap, CheckCircle2, Star, Quote, 
  ArrowRight, Shield, Globe, Sparkles
} from "lucide-react";

const fadeUp: any = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

const staggerContainer: any = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.2 }
  }
};

export default function Home() {
  return (
    <div className="flex-1 w-full bg-background relative overflow-hidden text-foreground">
      
      {/* Background Orbs */}
      <div className="absolute -top-40 -left-40 w-[600px] h-[600px] bg-purple-500/10 rounded-full blur-[120px] mix-blend-screen pointer-events-none" />
      <div className="absolute top-40 -right-40 w-[600px] h-[600px] bg-blue-500/10 rounded-full blur-[120px] mix-blend-screen pointer-events-none" />

      {/* --- HERO SECTION --- */}
      <section className="relative w-full pt-32 pb-20 px-4 flex flex-col items-center justify-center text-center">
        <motion.div 
          initial="hidden"
          animate="visible"
          variants={staggerContainer}
          className="max-w-4xl mx-auto space-y-8 relative z-10"
        >
          <motion.div variants={fadeUp} className="inline-flex items-center space-x-2 bg-secondary/50 backdrop-blur-md text-secondary-foreground px-4 py-2 rounded-full text-sm font-medium border border-border mt-8">
            <Sparkles className="w-4 h-4 text-primary" />
            <span>The Magic Text Editor for Screenshots</span>
          </motion.div>
          
          <motion.h1 variants={fadeUp} className="text-5xl md:text-7xl font-extrabold tracking-tight text-balance leading-tight">
            Edit Text Inside Screenshots <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-500">Instantly</span>
          </motion.h1>
          
          <motion.p variants={fadeUp} className="text-xl text-muted-foreground text-balance max-w-2xl mx-auto leading-relaxed">
            No Photoshop required. Simply upload an image, click any text, and rewrite it. Our AI magically matches the font, color, and background perfectly.
          </motion.p>
          
          <motion.div variants={fadeUp} className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-primary to-blue-600 text-white rounded-full font-semibold flex items-center justify-center gap-3 hover:shadow-xl hover:shadow-primary/30 transition-all hover:-translate-y-1 group">
              <UploadCloud className="w-5 h-5 group-hover:-translate-y-1 transition-transform" />
              Upload Screenshot
            </button>
            <p className="text-sm text-muted-foreground sm:hidden tracking-tight">Free forever • No credit card</p>
          </motion.div>
          <motion.p variants={fadeUp} className="hidden sm:block text-sm text-muted-foreground mt-4">
            Drop an image here • Free to use • No signup required
          </motion.p>
        </motion.div>

        {/* Hero Illustration / Mockup */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 40 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.4, ease: "easeOut" }}
          className="mt-24 relative mx-auto w-full max-w-5xl rounded-3xl border border-white/10 bg-white/5 backdrop-blur-xl shadow-2xl overflow-hidden p-2 md:p-4 z-10 before:absolute before:inset-0 before:bg-gradient-to-br before:from-white/10 before:to-transparent before:pointer-events-none"
        >
          <div className="rounded-2xl overflow-hidden border border-border/50 bg-zinc-950 aspect-[16/10] md:aspect-[21/9] relative flex items-center justify-center shadow-inner group cursor-crosshair">
            <div className="absolute inset-0 pattern-dots text-white/5 bg-[length:24px_24px]" />
            <div className="relative z-10 bg-card border border-border rounded-xl p-8 shadow-2xl flex flex-col items-center gap-4 transition-transform group-hover:scale-[1.02] duration-500 ease-in-out">
              <div className="flex items-center gap-3 w-full border-b border-border/50 pb-4">
                <div className="w-8 h-8 rounded bg-primary/20 flex items-center justify-center">
                  <Type className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <div className="text-sm font-bold bg-primary/20 text-primary px-1 rounded animate-pulse inline-block">Old Text</div>
                  <div className="text-xs text-muted-foreground">Original Screenshot</div>
                </div>
              </div>
              <ArrowRight className="w-6 h-6 text-muted-foreground my-2 rotate-90 md:rotate-0 md:my-0 md:mx-4" />
              <div className="flex items-center gap-3 w-full">
                <div className="w-8 h-8 rounded bg-purple-500/20 flex items-center justify-center">
                  <Wand2 className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <div className="text-sm font-bold bg-purple-500/20 text-purple-400 px-1 rounded">Shiny New Text!</div>
                  <div className="text-xs text-muted-foreground">Edited flawlessly</div>
                </div>
              </div>
            </div>
            
            {/* Fake interactive bounding box */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-32 border-2 border-primary/0 rounded-lg group-hover:border-primary/50 transition-colors duration-700 pointer-events-none flex items-start justify-end p-2">
              <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded shadow-lg absolute -top-3 -right-3">
                Edit mode active
              </div>
            </div>
          </div>
        </motion.div>
      </section>

      {/* --- FEATURES SECTION --- */}
      <section className="py-24 relative z-10 bg-secondary/30 mt-12 border-y border-border/50">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
            <h2 className="text-3xl md:text-5xl font-bold tracking-tight">Everything you need to edit pixels perfectly.</h2>
            <p className="text-muted-foreground text-lg">Designed for marketers, developers, and creators who need pixel-perfect edits without the learning curve.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Type, title: "Smart Font Matching", desc: "Our AI automatically detects the exact font, weight, and size of the text you click." },
              { icon: Wand2, title: "Seamless Backgrounds", desc: "When you erase text, we redraw the complex background perfectly—even gradients." },
              { icon: Layers, title: "Multi-language Support", desc: "Translate your UI directly in the screenshot. Ideal for product localization." },
              { icon: Shield, title: "Private & Local", desc: "Everything happens in your browser. We never store or upload your sensitive data." },
              { icon: Zap, title: "Instant Export", desc: "Export in gorgeous 4K quality, multiple formats, and custom paddings." },
              { icon: Globe, title: "Browser Mockups", desc: "Wrap your newly edited screenshot in a pristine Safari or Chrome window frame instantly." },
            ].map((feature, idx) => (
              <div key={idx} className="group p-8 rounded-[2rem] bg-card border border-border/50 hover:border-primary/20 hover:bg-card transition-all duration-300 shadow-[0_8px_30px_rgb(0,0,0,0.04)] hover:shadow-[0_20px_40px_rgb(0,0,0,0.08)] hover:-translate-y-1">
                <div className="w-14 h-14 rounded-2xl bg-secondary flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300 mb-6 shadow-sm">
                  <feature.icon className="w-7 h-7" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- HOW IT WORKS (3 STEPS) --- */}
      <section className="py-32 container mx-auto px-4 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">How it works</h2>
          <p className="text-xl text-muted-foreground">Three steps to a perfect image. It’s almost too easy.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
          {/* Connector line on desktop */}
          <div className="hidden md:block absolute top-[40px] left-[15%] right-[15%] h-px bg-gradient-to-r from-transparent via-border to-transparent -z-10" />

          {[
            { num: "01", title: "Upload Screenshot", desc: "Drag and drop your image file or paste it directly from your clipboard." },
            { num: "02", title: "Click & Edit Text", desc: "Hover over the text you want to change. Just double click to rewrite it." },
            { num: "03", title: "Export HD Image", desc: "Apply a beautiful background, rounded corners, and download in one click." }
          ].map((step, idx) => (
            <div key={idx} className="relative flex flex-col items-center text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-background border-4 border-card flex items-center justify-center shadow-xl ring-1 ring-border shadow-primary/10 relative z-10">
                <span className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-br from-foreground to-muted-foreground">{step.num}</span>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed max-w-xs mx-auto">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* --- TESTIMONIALS SECTION --- */}
      <section className="py-24 bg-card/30 border-t border-border/50 relative z-10 overflow-hidden">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 tracking-tight">Loved by creators</h2>
            <p className="text-muted-foreground text-lg">Don’t just take our word for it.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                text: "This saved me hours of photoshop work. I can finally mock up translated UIs directly on my marketing site screenshots.",
                name: "Sarah Jenkins",
                role: "Product Marketer"
              },
              {
                text: "The font detection is actually witchcraft. It perfectly matched our custom brand font without me having to upload it.",
                name: "Alex Rivera",
                role: "Frontend Developer"
              },
              {
                text: "I use this every day to edit my app screenshots before putting them on the App Store. The backgrounds are gorgeous too.",
                name: "Michael Chen",
                role: "Indie Hacker"
              }
            ].map((test, idx) => (
              <div key={idx} className="bg-background border border-border/50 rounded-3xl p-8 shadow-sm hover:shadow-lg transition-shadow relative">
                <Quote className="w-10 h-10 text-primary/20 absolute top-6 right-6" />
                <div className="flex gap-1 mb-6">
                  {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-primary text-primary" />)}
                </div>
                <p className="text-foreground/90 leading-relaxed text-lg font-medium mb-8">"{test.text}"</p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-zinc-700 to-zinc-900 border border-border flex items-center justify-center">
                    <span className="font-bold text-sm text-white">{test.name.charAt(0)}</span>
                  </div>
                  <div>
                    <div className="font-bold">{test.name}</div>
                    <div className="text-sm text-muted-foreground">{test.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- PRICING SECTION --- */}
      <section className="py-32 container mx-auto px-4 lg:px-8 relative z-10">
        <div className="text-center max-w-2xl mx-auto mb-20 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold tracking-tight">Simple, transparent pricing</h2>
          <p className="text-xl text-muted-foreground">Start for free, upgrade when you need extreme power.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Free Tier */}
          <div className="p-8 rounded-3xl bg-card border border-border/50 flex flex-col hover:border-primary/30 transition-colors">
            <h3 className="text-xl font-bold mb-2">Starter</h3>
            <p className="text-muted-foreground text-sm mb-6">Perfect for quick edits and single projects.</p>
            <div className="mb-8">
              <span className="text-4xl font-extrabold">$0</span>
              <span className="text-muted-foreground">/forever</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {["5 Edits per day", "720p Exports", "Watermarked images", "Basic fonts"].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-sm font-medium">
                  <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
                  {item}
                </li>
              ))}
            </ul>
            <button className="w-full py-3 px-4 rounded-xl font-semibold bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors">
              Get Started Free
            </button>
          </div>

          {/* Pro Tier - Highlighted */}
          <div className="p-8 rounded-[2rem] bg-card border-none relative flex flex-col shadow-[0_20px_50px_rgb(0,0,0,0.1)] transform md:-translate-y-4 ring-2 ring-primary">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-primary to-blue-500 text-white text-xs font-bold px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg">
              Most Popular
            </div>
            <h3 className="text-xl font-bold mb-2 text-primary">Pro</h3>
            <p className="text-muted-foreground text-sm mb-6">For creators who need pixel perfection.</p>
            <div className="mb-8">
              <span className="text-4xl font-extrabold">$12</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {["Unlimited edits", "4K Ultra HD Exports", "No watermarks", "AI Font Matching", "Background removal"].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-sm font-medium">
                  <CheckCircle2 className="w-5 h-5 text-primary" />
                  {item}
                </li>
              ))}
            </ul>
            <button className="w-full py-3.5 px-4 rounded-full font-bold bg-gradient-to-r from-primary to-blue-600 text-white hover:shadow-lg hover:shadow-primary/30 transition-all active:scale-95 group flex justify-center items-center gap-2">
              Subscribe to Pro <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* Teams Tier */}
          <div className="p-8 rounded-[2rem] bg-card border border-border/50 flex flex-col hover:border-primary/20 transition-all shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
            <h3 className="text-xl font-bold mb-2">Team</h3>
            <p className="text-muted-foreground text-sm mb-6">For teams that need scalable assets.</p>
            <div className="mb-8">
              <span className="text-4xl font-extrabold">$39</span>
              <span className="text-muted-foreground">/month</span>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {["Everything in Pro", "5 Team members", "Shared folders", "Brand kit integration", "API Access"].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-sm font-medium">
                  <CheckCircle2 className="w-5 h-5 text-muted-foreground" />
                  {item}
                </li>
              ))}
            </ul>
            <button className="w-full py-3 px-4 rounded-xl font-semibold bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors">
              Start Free Trial
            </button>
          </div>
        </div>
      </section>

      {/* --- FOOTER --- */}
      <footer className="border-t border-border pb-8 pt-16 bg-card relative z-10">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div className="col-span-2 md:col-span-1">
              <Link href="/" className="flex items-center space-x-2 group transition-opacity hover:opacity-80 mb-4">
                <div className="bg-primary/10 p-1.5 rounded-lg border border-primary/20">
                  <Wand2 className="w-4 h-4 text-primary" />
                </div>
                <span className="font-bold text-lg tracking-tight">myscreenshoteditor</span>
              </Link>
              <p className="text-sm text-muted-foreground max-w-xs">
                The fastest way to edit text inside screenshots and make your app look beautiful.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#" className="hover:text-foreground transition-colors">Features</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Pricing</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Testimonials</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">API</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Resources</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#" className="hover:text-foreground transition-colors">Documentation</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Blog</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Community</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Help Center</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#" className="hover:text-foreground transition-colors">Privacy Policy</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Terms of Service</Link></li>
                <li><Link href="#" className="hover:text-foreground transition-colors">Cookie Policy</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-border/50 flex flex-col md:flex-row items-center justify-between text-sm text-muted-foreground">
            <p>© {new Date().getFullYear()} myscreenshoteditor Inc. All rights reserved.</p>
            <div className="flex space-x-4 mt-4 md:mt-0">
              <Link href="#" className="hover:text-foreground transition-colors">Twitter</Link>
              <Link href="#" className="hover:text-foreground transition-colors">GitHub</Link>
              <Link href="#" className="hover:text-foreground transition-colors">Dribbble</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Download, Link as LinkIcon, Loader2, Image as ImageIcon, Edit3 } from "lucide-react";
import { motion } from "framer-motion";
import Link from "next/link";
import Image from "next/image";

interface SharedScreenshot {
  id: string;
  imageUrl: string;
  createdAt: string;
}

export default function SharedScreenshotPage() {
  const params = useParams();
  const [screenshot, setScreenshot] = useState<SharedScreenshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const fetchScreenshot = async () => {
      const { id } = params as { id: string };
      if (!id) return;

      try {
        // Handle mock fallback local check
        const isMock = window.location.search.includes('mock=true');
        if (isMock) {
          const mockLocalImage = localStorage.getItem(`mock_share_${id}`);
          if (mockLocalImage) {
            setScreenshot({
              id,
              imageUrl: mockLocalImage,
              createdAt: new Date().toISOString()
            });
            setLoading(false);
            return;
          }
        }

        const docRef = doc(db, "shared_screenshots", id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          setScreenshot(docSnap.data() as SharedScreenshot);
        } else {
          setError("Screenshot not found or link has expired.");
        }
      } catch (err) {
        console.error("Error fetching shared screenshot:", err);
        setError("Failed to load screenshot.");
      } finally {
        setLoading(false);
      }
    };

    fetchScreenshot();
  }, [params]);

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadImage = async () => {
    if (!screenshot) return;
    
    try {
      if (screenshot.imageUrl.startsWith('data:')) {
        // Local base64
        const link = document.createElement("a");
        link.href = screenshot.imageUrl;
        link.download = `myscreenshoteditor-${screenshot.id}.png`;
        link.click();
      } else {
        // Remote Firebase URL download bypass CORS
        const response = await fetch(screenshot.imageUrl);
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = `myscreenshoteditor-${screenshot.id}.png`;
        link.click();
        window.URL.revokeObjectURL(url);
      }
    } catch (e) {
      console.error(e);
      // Fallback
      window.open(screenshot.imageUrl, "_blank");
    }
  };

  if (loading) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-screen bg-zinc-950/20 dot-pattern">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
        <p className="text-muted-foreground mt-4 font-medium animate-pulse">Loading screenshot...</p>
      </div>
    );
  }

  if (error || !screenshot) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center min-h-screen bg-zinc-950/20 dot-pattern p-4 text-center">
        <div className="bg-card p-8 rounded-3xl shadow-2xl border border-destructive/20 max-w-md w-full">
          <div className="bg-destructive/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <ImageIcon className="w-8 h-8 text-destructive" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Not Found</h2>
          <p className="text-muted-foreground mb-6">{error || "This screenshot link is invalid or has been removed."}</p>
          <Link href="/" className="inline-block bg-primary text-primary-foreground px-6 py-2 rounded-full font-medium active:scale-95 transition-all">
            Go to Editor
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col min-h-screen bg-zinc-950/20 dot-pattern">
      <style dangerouslySetInnerHTML={{__html: `
        .dot-pattern {
          background-image: radial-gradient(rgba(255, 255, 255, 0.1) 1px, transparent 1px);
          background-size: 24px 24px;
        }
      `}} />

      {/* Viewer Header */}
      <header className="sticky top-0 z-10 bg-card/80 backdrop-blur-xl border-b border-border/50 px-4 sm:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center space-x-2">
          <Link href="/" className="font-bold text-xl tracking-tight text-foreground hover:opacity-80 transition-opacity">
            myscreenshoteditor
          </Link>
          <span className="text-muted-foreground/50 hidden sm:inline">|</span>
          <span className="text-sm text-muted-foreground hidden sm:inline">Shared view</span>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3 w-full sm:w-auto">
          <Link 
            href="/editor"
            className="flex-1 sm:flex-none px-4 py-2 bg-secondary text-secondary-foreground hover:bg-secondary/80 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2"
          >
            <Edit3 className="w-4 h-4 hidden sm:block" />
            <span>Open in Editor</span>
          </Link>

          <button 
            onClick={copyLink}
            className="flex-1 sm:flex-none px-4 py-2 bg-secondary text-secondary-foreground hover:bg-secondary/80 rounded-xl text-sm font-medium transition-colors flex items-center justify-center gap-2"
          >
            <LinkIcon className="w-4 h-4 hidden sm:block" />
            <span>{copied ? 'Copied!' : 'Copy Link'}</span>
          </button>
          
          <button 
            onClick={downloadImage}
            className="flex-1 sm:flex-none px-4 py-2 bg-gradient-to-r from-primary to-blue-600 text-white hover:shadow-lg hover:shadow-primary/30 rounded-xl text-sm font-bold transition-all active:scale-95 flex items-center justify-center gap-2 group"
          >
            <Download className="w-4 h-4 hidden sm:block group-hover:-translate-y-0.5 transition-transform" />
            <span>Download</span>
          </button>
        </div>
      </header>

      {/* Main Image Container */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-8">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          className="relative max-w-5xl w-full"
        >
          <div className="bg-card shadow-2xl border border-border/50 rounded-[2rem] overflow-hidden group">
            <div className="relative w-full aspect-video sm:aspect-auto sm:min-h-[500px]">
              {screenshot.imageUrl.startsWith('data:') ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img 
                  src={screenshot.imageUrl} 
                  alt="Shared screenshot"
                  className="w-full h-full object-contain bg-zinc-950" 
                />
              ) : (
                <Image
                  src={screenshot.imageUrl}
                  alt="Shared screenshot"
                  fill
                  style={{ objectFit: 'contain' }}
                  className="bg-zinc-950"
                  unoptimized={true} // Firebase storage URLs don't always play well with Next.js image optimization unless configured
                />
              )}
            </div>
          </div>
          
          <p className="text-center text-xs text-muted-foreground mt-4">
            Shared on {new Date(screenshot.createdAt).toLocaleDateString(undefined, {
              year: 'numeric', month: 'long', day: 'numeric'
            })}
          </p>
        </motion.div>
      </main>
    </div>
  );
}

import Tesseract from "tesseract.js";

export interface DetectedFontBlock {
  id: string;
  text: string;
  bbox: { x0: number; y0: number; x1: number; y1: number };
  estimatedFontSize: number;
  fontStylePrediction: string;
  confidenceScore: number;
  croppedImageBase64: string;
}

export interface FontMatchResult {
  fontStylePrediction: string;
  confidenceScore: number;
}

/**
 * Dynamically loads a font from Google Fonts API and waits for the browser to parse it.
 * This guarantees the Canvas can render the text natively without FOUT (Flash of Unstyled Text).
 */
export const loadGoogleFont = async (fontStylePrediction: string): Promise<void> => {
  if (typeof document === "undefined") return;

  // Extract the raw font name (e.g. "Inter, sans-serif" -> "Inter")
  const fontName = fontStylePrediction.split(',')[0].trim().replace(/['"]/g, '');
  
  // System fonts don't exist on Google Fonts, fallback naturally
  const excludeFonts = ['Arial', 'Helvetica', 'system-ui', 'sans-serif', 'serif'];
  if (excludeFonts.includes(fontName)) return;

  const formattedName = fontName.replace(/ /g, '+');
  const fontUrl = `https://fonts.googleapis.com/css2?family=${formattedName}:wght@400;500;600;700&display=swap`;
  
  // Abort if the font stylesheet is already injected into the DOM
  if (document.querySelector(`link[href="${fontUrl}"]`)) {
    try {
      await document.fonts.load(`16px "${fontName}"`);
    } catch (e) {}
    return;
  }

  // Inject stylesheet and await native resolution
  return new Promise((resolve) => {
    const link = document.createElement('link');
    link.href = fontUrl;
    link.rel = 'stylesheet';
    
    link.onload = async () => {
      try {
        await document.fonts.load(`16px "${fontName}"`);
      } catch (err) {
        console.warn(`Failed to inherently preload font ${fontName}`, err);
      }
      resolve();
    };
    
    link.onerror = () => {
      console.warn(`Google Font API failed to resolve ${fontName}. Falling back to system fonts.`);
      resolve(); // Resolve to prevent halting the main rendering thread
    };
    
    document.head.appendChild(link);
  });
};

/**
 * Crops a specific region from an HTMLImageElement using an offscreen canvas.
 */
const cropImageRegion = (
  image: HTMLImageElement,
  bbox: { x0: number; y0: number; x1: number; y1: number }
): string => {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");
  
  const width = bbox.x1 - bbox.x0;
  const height = bbox.y1 - bbox.y0;
  
  // Padding to ensure we capture the whole text
  const padding = 4;
  const sx = Math.max(0, bbox.x0 - padding);
  const sy = Math.max(0, bbox.y0 - padding);
  const sw = Math.min(image.width - sx, width + padding * 2);
  const sh = Math.min(image.height - sy, height + padding * 2);

  canvas.width = sw;
  canvas.height = sh;

  if (ctx) {
    ctx.drawImage(image, sx, sy, sw, sh, 0, 0, sw, sh);
    return canvas.toDataURL("image/png");
  }
  
  return "";
};

/**
 * Represents numerical features extracted from typography (Mocked)
 * These represent things like: stroke width, terminal curvature, x-height, and aspect ratio.
 */
interface FontFeatureVector {
  strokeWidth: number;
  xHeightRatio: number;
  curvature: number;
  aspectRatio: number;
}

// 1. Font Database containing common target web fonts
const FONT_DATABASE: Record<string, FontFeatureVector> = {
  "Roboto, sans-serif": { strokeWidth: 0.5, xHeightRatio: 0.7, curvature: 0.3, aspectRatio: 0.8 },
  "Inter, sans-serif": { strokeWidth: 0.55, xHeightRatio: 0.75, curvature: 0.2, aspectRatio: 0.85 },
  "Open Sans, sans-serif": { strokeWidth: 0.6, xHeightRatio: 0.65, curvature: 0.4, aspectRatio: 0.9 },
  "Arial, sans-serif": { strokeWidth: 0.45, xHeightRatio: 0.6, curvature: 0.5, aspectRatio: 0.75 },
  "Helvetica, sans-serif": { strokeWidth: 0.48, xHeightRatio: 0.62, curvature: 0.45, aspectRatio: 0.78 },
  "Montserrat, sans-serif": { strokeWidth: 0.7, xHeightRatio: 0.8, curvature: 0.8, aspectRatio: 1.0 },
  "Poppins, sans-serif": { strokeWidth: 0.65, xHeightRatio: 0.78, curvature: 0.9, aspectRatio: 1.05 },
};

/**
 * Calculates Euclidean distance between two feature vectors
 */
const calculateFeatureDistance = (v1: FontFeatureVector, v2: FontFeatureVector): number => {
  return Math.sqrt(
    Math.pow(v1.strokeWidth - v2.strokeWidth, 2) +
    Math.pow(v1.xHeightRatio - v2.xHeightRatio, 2) +
    Math.pow(v1.curvature - v2.curvature, 2) +
    Math.pow(v1.aspectRatio - v2.aspectRatio, 2)
  );
};

/**
 * Font Detection Engine Pipeline (Simulated)
 * Extracts numeric graphical features from the base64 crop, compares it against the database,
 * and yields the closest structural match alongside a probabilistic confidence score.
 */
const predictFontFromImage = async (base64Image: string): Promise<FontMatchResult> => {
  // Simulate network or ML inference latency
  await new Promise(resolve => setTimeout(resolve, 80));
  
  // Create a pseudo-random, deterministic feature vector based on the base64 string length
  const hash = base64Image.length;
  
  const extractedFeatures: FontFeatureVector = {
    // Math.sin generates pseudo-random bounds mapping to 0.0 - 1.0
    strokeWidth: Math.abs(Math.sin(hash)) * 0.8 + 0.2, 
    xHeightRatio: Math.abs(Math.cos(hash)) * 0.5 + 0.4,
    curvature: Math.abs(Math.sin(hash * 2)) * 0.9 + 0.1,
    aspectRatio: Math.abs(Math.cos(hash * 3)) * 0.6 + 0.6,
  };

  let bestMatch = "Inter, sans-serif"; // Fallback default
  let minDistance = Infinity;

  // Compare extracted features against the database
  for (const [fontName, dbFeatures] of Object.entries(FONT_DATABASE)) {
    const distance = calculateFeatureDistance(extractedFeatures, dbFeatures);
    
    if (distance < minDistance) {
      minDistance = distance;
      bestMatch = fontName;
    }
  }

  // Convert distance metrics to a readable confidence score (0% - 100%)
  // A perfect match (dist = 0) is 99%, an awful match pushes towards ~40%.
  const maxExpectedDistance = 1.5;
  let rawConfidence = 1 - (minDistance / maxExpectedDistance);
  rawConfidence = Math.max(0.4, Math.min(0.99, rawConfidence));

  return {
    fontStylePrediction: bestMatch,
    confidenceScore: Math.round(rawConfidence * 100),
  };
};

/**
 * Main Font Detection Module
 * 1. Runs OCR on the file to detect text and bounding boxes
 * 2. Iterates through lines and crops the image around the bounding box
 * 3. Sends cropped chunks to the font prediction pipeline
 */
export const extractTextAndFonts = async (
  file: File,
  imageElement: HTMLImageElement,
  onProgress?: (status: string, progress: number) => void
): Promise<DetectedFontBlock[]> => {
  
  if (onProgress) onProgress("Initializing OCR...", 0);
  
  // 1. Run Tesseract OCR
  const result = await Tesseract.recognize(file, "eng", {
    logger: m => {
      if (m.status === "recognizing text" && onProgress) {
        onProgress("Detecting text regions...", Math.floor(m.progress * 100));
      } else if (onProgress) {
        onProgress(m.status, 0);
      }
    }
  });

  const lines = (result.data as any)?.lines || [];
  
  if (onProgress) onProgress("Analyzing typography...", 100);

  // 2. Process each detected text block
  const detectedBlocks: DetectedFontBlock[] = [];
  
  for (let idx = 0; idx < lines.length; idx++) {
    const line = lines[idx];
    const text = line?.text?.trim() || "";
    
    // Ignore empty lines or noise
    if (text.length < 2) continue;

    const bbox = line?.bbox || { x0: 0, y0: 0, x1: 0, y1: 0 };
    
    // Estimate font size using OCR bounding box height
    const boxHeight = bbox.y1 - bbox.y0;
    const padding = Math.floor(boxHeight * 0.2); // Subtract 20% padding naturally found in OCR bounding boxes
    const estimatedFontSize = Math.max(12, boxHeight - padding);

    // 3. Crop the image exactly around the text box
    const croppedImageBase64 = cropImageRegion(imageElement, bbox);

    // 4. Send the cropped chunk to our feature-matching system
    const { fontStylePrediction, confidenceScore } = await predictFontFromImage(croppedImageBase64);

    detectedBlocks.push({
      id: `text-block-${idx}-${Date.now()}`,
      text,
      bbox,
      estimatedFontSize,
      fontStylePrediction,
      confidenceScore,
      croppedImageBase64
    });
  }

  return detectedBlocks;
};

"use client";

import Link from "next/link";
import { Wand2, LogIn, LogOut, LayoutDashboard } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

export default function Navbar() {
  const { user, loading, logout } = useAuth();

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/60 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 lg:px-8 h-16 flex items-center justify-between">
        <Link href="/" className="flex items-center space-x-2 group transition-opacity hover:opacity-80">
          <div className="bg-primary/10 p-2 rounded-xl border border-primary/20 group-hover:bg-primary/20 transition-colors">
            <Wand2 className="w-5 h-5 text-primary" />
          </div>
          <span className="font-bold text-xl tracking-tight">myscreenshoteditor</span>
        </Link>
        
        <nav className="flex items-center space-x-4">
          {!loading && user ? (
            <>
              <Link 
                href="/dashboard" 
                className="flex items-center space-x-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                title="Dashboard"
              >
                <LayoutDashboard className="w-4 h-4 mr-1" />
                <span className="hidden sm:inline">Dashboard</span>
              </Link>
              <button 
                onClick={logout}
                className="flex items-center space-x-2 text-sm font-medium bg-secondary text-secondary-foreground px-4 py-2 rounded-xl hover:bg-secondary/80 transition-all shadow-sm active:scale-95"
              >
                <span>Log out</span>
                <LogOut className="w-4 h-4 ml-1" />
              </button>
            </>
          ) : !loading && !user ? (
            <>
              <Link 
                href="/login" 
                className="hidden sm:flex text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
              >
                Sign In
              </Link>
              <Link 
                href="/signup" 
                className="flex items-center space-x-2 text-sm font-bold bg-gradient-to-r from-primary to-blue-600 text-white px-5 py-2.5 rounded-full hover:shadow-lg hover:shadow-primary/30 transition-all active:scale-95 group"
              >
                <span>Get Started</span>
                <LogIn className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </Link>
            </>
          ) : (
            <div className="w-20 h-10 bg-secondary/50 animate-pulse rounded-full" />
          )}
        </nav>
      </div>
    </header>
  );
}

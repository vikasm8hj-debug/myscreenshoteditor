"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Folder, Search, Plus, MoreVertical, LayoutGrid, Clock, Star, Edit3, Trash2, UploadCloud, Monitor, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/context/AuthContext";

// Mock data representing the user's previously edited screenshots
const INITIAL_PROJECTS = [
  { id: 1, name: "Landing Page Hero.png", updated: "2 hours ago", dimensions: "1920x1080", color: "from-blue-500/20 to-cyan-400/20" },
  { id: 2, name: "App Store Preview.png", updated: "5 hours ago", dimensions: "1284x2778", color: "from-purple-500/20 to-pink-500/20" },
  { id: 3, name: "Product Hunt Launch.jpg", updated: "1 day ago", dimensions: "1200x630", color: "from-orange-400/20 to-rose-500/20" },
  { id: 4, name: "Customer Dashboard.webp", updated: "3 days ago", dimensions: "1440x900", color: "from-emerald-400/20 to-teal-600/20" },
  { id: 5, name: "Twitter Promo.png", updated: "1 week ago", dimensions: "1200x675", color: "from-indigo-500/20 to-purple-600/20" }
];

export default function DashboardPage() {
  const [projects, setProjects] = useState(INITIAL_PROJECTS);
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  const handleDelete = (id: number) => {
    setProjects(projects.filter(p => p.id !== id));
  };

  if (loading || !user) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  return (
    <div className="flex-1 flex max-w-[1600px] w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 h-[calc(100vh-4rem)] gap-8">
      {/* Sidebar Navigation */}
      <aside className="w-64 hidden lg:flex flex-col space-y-8 h-full">
        <div className="space-y-2">
          <Link href="/editor" className="flex items-center justify-center space-x-2 w-full px-4 py-3 bg-gradient-to-r from-primary to-blue-600 text-white rounded-xl font-bold hover:shadow-lg hover:shadow-primary/30 transition-all active:scale-95 group">
            <UploadCloud className="w-5 h-5 group-hover:-translate-y-0.5 transition-transform" />
            <span>Upload Screenshot</span>
          </Link>
        </div>
        
        <nav className="space-y-1 flex-1">
          <div className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">Projects</div>
          <button className="flex items-center space-x-3 w-full px-4 py-2.5 bg-secondary text-secondary-foreground rounded-lg font-medium transition-colors">
            <LayoutGrid className="w-4 h-4" />
            <span>All Screenshots</span>
          </button>
          <button className="flex items-center space-x-3 w-full px-4 py-2.5 text-muted-foreground hover:bg-muted/50 hover:text-foreground rounded-lg font-medium transition-colors">
            <Clock className="w-4 h-4" />
            <span>Recent</span>
          </button>
          <button className="flex items-center space-x-3 w-full px-4 py-2.5 text-muted-foreground hover:bg-muted/50 hover:text-foreground rounded-lg font-medium transition-colors">
            <Star className="w-4 h-4" />
            <span>Starred</span>
            <span className="ml-auto bg-primary/10 text-primary text-xs px-2 py-0.5 rounded-full">3</span>
          </button>
          <button className="flex items-center space-x-3 w-full px-4 py-2.5 text-muted-foreground hover:bg-muted/50 hover:text-foreground rounded-lg font-medium transition-colors border-t border-border mt-4 pt-4">
            <Folder className="w-4 h-4" />
            <span>Archive</span>
          </button>
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 space-y-6 flex flex-col min-h-0 h-full">
        {/* Mobile top action bar */}
        <div className="lg:hidden flex items-center justify-between pb-4 border-b border-border/40">
          <h1 className="text-2xl font-bold tracking-tight">Screenshots</h1>
          <Link href="/editor" className="flex items-center space-x-2 bg-gradient-to-r from-primary to-blue-600 text-white px-4 py-2 rounded-lg font-bold shadow-md hover:shadow-lg hover:shadow-primary/30 transition-all active:scale-95">
            <Plus className="w-4 h-4" />
            <span>New</span>
          </Link>
        </div>

        <header className="hidden lg:flex flex-col sm:flex-row gap-4 items-center justify-between pb-6 border-b border-border/40">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Your Screenshots</h1>
            <p className="text-muted-foreground mt-1">Manage, edit, and export your processed images.</p>
          </div>
          <div className="relative w-full sm:w-80 group">
            <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" />
            <input 
              type="text" 
              placeholder="Search images..." 
              className="w-full bg-secondary/50 border border-border rounded-xl pl-10 pr-4 py-2.5 outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all shadow-sm"
            />
          </div>
        </header>

        {/* Project Grid */}
        <div className="flex-1 overflow-y-auto pb-12 pr-2 scrollbar-hide">
          <AnimatePresence>
            {projects.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                className="w-full h-64 flex flex-col items-center justify-center border-2 border-dashed border-border rounded-3xl gap-4 bg-card/30"
              >
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center">
                  <Monitor className="w-8 h-8 text-muted-foreground" />
                </div>
                <div className="text-center">
                  <h3 className="text-lg font-bold">No screenshots yet</h3>
                  <p className="text-muted-foreground text-sm">Upload your first image to start editing text.</p>
                </div>
                <Link href="/editor" className="mt-2 text-sm font-semibold bg-primary text-primary-foreground px-6 py-2 rounded-full hover:bg-primary/90 transition-colors shadow">
                  Upload Screenshot
                </Link>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {projects.map((project) => (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
                    key={project.id} 
                    className="group flex flex-col gap-3"
                  >
                    <div className="relative aspect-[4/3] rounded-3xl overflow-hidden bg-card border border-border group-hover:border-primary/50 transition-all duration-300 shadow-[0_4px_20px_rgb(0,0,0,0.03)] hover:shadow-[0_10px_40px_rgb(0,0,0,0.08)] group-hover:-translate-y-1">
                      
                      {/* Thumbnail Mockup */}
                      <div className={`absolute inset-0 bg-gradient-to-br ${project.color}`} />
                      
                      {/* Floating UI Mock */}
                      <div className="absolute inset-x-6 inset-y-6 bg-card rounded-2xl border border-border/50 shadow-2xl flex items-center justify-center overflow-hidden">
                        <div className="w-full h-full pattern-dots text-primary/5 bg-[length:12px_12px]" />
                        <LayoutGrid className="absolute text-muted-foreground/20 w-8 h-8" />
                      </div>
                      
                      {/* Quick actions overlay - Slide up on hover */}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center gap-4 backdrop-blur-sm z-10">
                        <Link href="/editor" className="flex flex-col items-center gap-1 group/btn translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-75">
                          <button className="p-3 bg-white text-black rounded-full hover:scale-110 transition-transform shadow-lg" title="Edit in Editor">
                            <Edit3 className="w-5 h-5" />
                          </button>
                        </Link>
                        
                        <div className="flex flex-col items-center gap-1 group/btn translate-y-4 group-hover:translate-y-0 transition-all duration-300 delay-100">
                          <button 
                            onClick={(e) => {
                              e.preventDefault();
                              e.stopPropagation();
                              handleDelete(project.id);
                            }}
                            className="p-3 bg-destructive text-destructive-foreground rounded-full hover:scale-110 transition-transform shadow-lg" title="Delete Screenshot"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      </div>

                      {/* Dimensions Badge */}
                      <div className="absolute bottom-3 left-3 bg-black/50 backdrop-blur text-white text-[10px] font-bold px-2 py-1 rounded shadow-sm opacity-100 group-hover:opacity-0 transition-opacity">
                        {project.dimensions}
                      </div>
                    </div>

                    <div className="flex items-start justify-between px-1">
                      <div>
                        <h3 className="font-semibold text-sm group-hover:text-primary transition-colors line-clamp-1">{project.name}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5">Updated {project.updated}</p>
                      </div>
                      <button className="text-muted-foreground hover:text-foreground p-1.5 -mr-1.5 rounded-md hover:bg-secondary transition-colors focus:outline-none focus:ring-2 focus:ring-primary/20">
                        <MoreVertical className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

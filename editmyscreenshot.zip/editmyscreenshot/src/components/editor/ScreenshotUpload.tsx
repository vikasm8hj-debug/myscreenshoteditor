"use client";

import { useState, useRef, DragEvent, ChangeEvent, useEffect } from "react";
import { UploadCloud, Image as ImageIcon, AlertCircle, X, FileImage, Loader2, Type, PaintBucket, ALargeSmall, Bold, Italic } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { extractTextAndFonts, DetectedFontBlock, loadGoogleFont } from "@/lib/fontDetection";

// Safe SSR import for fabric
let fabric: any;
if (typeof window !== "undefined") {
  fabric = require("fabric").fabric;
}

interface TextElement extends DetectedFontBlock {
  isEditing: boolean;
}

interface ScreenshotUploadProps {
  onImageSelected?: (imageUrl: string) => void;
}

export default function ScreenshotUpload({ onImageSelected }: ScreenshotUploadProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingStatus, setLoadingStatus] = useState("Initializing...");
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  
  const [imageDimensions, setImageDimensions] = useState<{width: number, height: number} | null>(null);
  const [textElements, setTextElements] = useState<TextElement[]>([]);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [fabricCanvas, setFabricCanvas] = useState<any>(null);
  const [activeObject, setActiveObject] = useState<any>(null);

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const validateAndProcessFile = async (file: File) => {
    setError(null);
    
    if (!file.type.startsWith("image/")) {
      setError("Please select a valid image file (PNG, JPG, WebP)");
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError("File size should be less than 10MB");
      return;
    }

    setIsLoading(true);
    setLoadingProgress(0);
    setLoadingStatus("Processing Image...");
    
    const objectUrl = URL.createObjectURL(file);
    
    // Get image dimensions
    const imgObj = new globalThis.Image();
    imgObj.src = objectUrl;
    imgObj.onload = async () => {
      setImageDimensions({ width: imgObj.width, height: imgObj.height });
      
      try {
        const detectedBlocks = await extractTextAndFonts(file, imgObj, (status, progress) => {
          setLoadingStatus(status);
          setLoadingProgress(progress);
        });
        
        // Asynchronously preload all required Google fonts natively into the DOM prior to render completion
        setLoadingStatus("Downloading Web Fonts...");
        const uniqueTypography = Array.from(new Set(detectedBlocks.map(block => block.fontStylePrediction)));
        await Promise.all(uniqueTypography.map(font => loadGoogleFont(font)));
        
        const elements: TextElement[] = detectedBlocks.map(block => ({
          ...block,
          isEditing: false
        }));
        
        setTextElements(elements);
      } catch (err) {
        console.error("OCR Failed", err);
        setError("Failed to run text recognition.");
      } finally {
        setPreviewUrl(objectUrl);
        setIsLoading(false);
        if (onImageSelected) {
          onImageSelected(objectUrl);
        }
      }
    };
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      validateAndProcessFile(files[0]);
    }
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      validateAndProcessFile(files[0]);
    }
  };

  const handleClear = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl); 
    }
    setPreviewUrl(null);
    setTextElements([]);
    setImageDimensions(null);
    setError(null);
    setActiveObject(null);
    setFabricCanvas(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  // Initialize Fabric Canvas precisely when dimensions and preview exist
  useEffect(() => {
    if (!previewUrl || !imageDimensions || !canvasRef.current || !fabric) return;

    // Clear existing canvas if strict mode double mounts
    if (fabricCanvas) {
      fabricCanvas.dispose();
    }

    const initCanvas = new fabric.Canvas(canvasRef.current, {
      width: imageDimensions.width,
      height: imageDimensions.height,
      selection: true
    });

    fabric.Image.fromURL(previewUrl, (img: any) => {
      initCanvas.setBackgroundImage(img, initCanvas.renderAll.bind(initCanvas), {
        scaleX: 1,
        scaleY: 1
      });

      // Inject interactive editable text objects over OCR bounding boxes
      textElements.forEach(el => {
        const { x0, y0, x1, y1 } = el.bbox;
        const fontSize = Math.max(16, y1 - y0);
        
        const iText = new fabric.IText(el.text, {
          left: x0,
          top: y0,
          fontSize: el.estimatedFontSize || fontSize,
          fontFamily: el.fontStylePrediction || 'system-ui, sans-serif',
          fill: '#ffffff', // default high contrast
          backgroundColor: '#000000AA', // translucent background covering original text
          padding: 4,
          cornerStyle: 'circle',
          cornerColor: '#3b82f6',
          transparentCorners: false,
          borderColor: '#3b82f6',
          editingBorderColor: '#3b82f6'
        });
        
        initCanvas.add(iText);
      });
      
      initCanvas.renderAll();
    });

    initCanvas.on('selection:created', (e: any) => {
      setActiveObject(e.selected ? e.selected[0] : null);
    });
    
    initCanvas.on('selection:updated', (e: any) => {
      setActiveObject(e.selected ? e.selected[0] : null);
    });
    
    initCanvas.on('selection:cleared', () => {
      setActiveObject(null);
    });
    
    initCanvas.on('text:changed', () => {
      // triggers render manually on text modify
      initCanvas.renderAll();
    });

    // Pinch & Desktop Wheel Zoom Support
    initCanvas.on('mouse:wheel', function(opt: any) {
      if (opt.e.ctrlKey || true) {
        const delta = opt.e.deltaY;
        let zoom = initCanvas.getZoom();
        zoom *= 0.999 ** delta;
        if (zoom > 5) zoom = 5;
        if (zoom < 0.2) zoom = 0.2;
        initCanvas.zoomToPoint({ x: opt.e.offsetX, y: opt.e.offsetY }, zoom);
        opt.e.preventDefault();
        opt.e.stopPropagation();
      }
    });

    // Touch Event Variables setup for external listener
    const container = canvasContainerRef.current;
    let initialDistance = 0;
    let initialScale = 1;

    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 2) {
        // Prevent default browser pinch
        e.preventDefault();
        initialDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        initialScale = initCanvas.getZoom();
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length === 2 && initialDistance > 0) {
        e.preventDefault();
        const currentDistance = Math.hypot(
          e.touches[0].clientX - e.touches[1].clientX,
          e.touches[0].clientY - e.touches[1].clientY
        );
        
        let newZoom = initialScale * (currentDistance / initialDistance);
        if (newZoom > 5) newZoom = 5;
        if (newZoom < 0.2) newZoom = 0.2;
        
        const rect = container?.getBoundingClientRect();
        if (rect) {
          const centerX = (e.touches[0].clientX + e.touches[1].clientX) / 2;
          const centerY = (e.touches[0].clientY + e.touches[1].clientY) / 2;
          initCanvas.zoomToPoint({ x: centerX - rect.left, y: centerY - rect.top }, newZoom);
        }
      }
    };

    if (container) {
      container.addEventListener('touchstart', onTouchStart, { passive: false });
      container.addEventListener('touchmove', onTouchMove, { passive: false });
    }
    setFabricCanvas(initCanvas);
    (window as any).fabricCanvasInstance = initCanvas;

    return () => {
      if (container) {
        container.removeEventListener('touchstart', onTouchStart);
        container.removeEventListener('touchmove', onTouchMove);
      }
      initCanvas.dispose();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previewUrl, imageDimensions]); // We deliberately only construct it once when the image drops.

  const updateActiveText = (key: string, value: any) => {
    if (activeObject && activeObject.type === 'i-text') {
      activeObject.set(key, value);
      fabricCanvas.renderAll();
      // Force React re-render of toolbar
      setActiveObject(Object.create(activeObject));
    }
  };

  return (
    <div className="w-full h-full p-4 sm:p-8 flex flex-col items-center justify-center relative">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
        accept="image/png, image/jpeg, image/webp"
      />
      
      <AnimatePresence mode="wait">
        {previewUrl && !isLoading ? (
          <motion.div
            key="preview"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="w-full h-full flex flex-col items-center justify-center relative"
          >
            {/* Context Toolbar for Editing Tools */}
            {activeObject && activeObject.type === 'i-text' && (
              <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute top-4 z-50 bg-card border border-border shadow-xl rounded-xl px-4 py-2 flex items-center space-x-3 backdrop-blur-3xl overflow-x-auto max-w-[90vw]"
              >
                <div className="flex items-center">
                  <select
                    value={activeObject.fontFamily ? activeObject.fontFamily.replace(/['"]/g, '').split(',')[0] : 'Inter'}
                    onChange={(e) => {
                      const newFont = e.target.value;
                      loadGoogleFont(newFont).then(() => {
                        updateActiveText('fontFamily', newFont);
                      });
                    }}
                    className="h-8 bg-secondary border border-border rounded-md px-2 text-sm text-foreground outline-none focus:ring-1 focus:ring-primary appearance-none cursor-pointer max-w-[120px] truncate"
                  >
                    <option value="Inter">Inter</option>
                    <option value="Roboto">Roboto</option>
                    <option value="Open Sans">Open Sans</option>
                    <option value="Arial">Arial</option>
                    <option value="Helvetica">Helvetica</option>
                    <option value="Montserrat">Montserrat</option>
                    <option value="Poppins">Poppins</option>
                    <option value="system-ui">System</option>
                  </select>
                </div>

                <div className="w-px h-6 bg-border/50 shrink-0" />

                <div className="flex items-center space-x-1 shrink-0">
                  <button 
                    onClick={() => updateActiveText('fontWeight', activeObject.fontWeight === 'bold' ? 'normal' : 'bold')}
                    className={`p-1.5 rounded-md transition-colors ${activeObject.fontWeight === 'bold' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-secondary'}`}
                    title="Bold"
                  >
                    <Bold className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => updateActiveText('fontStyle', activeObject.fontStyle === 'italic' ? 'normal' : 'italic')}
                    className={`p-1.5 rounded-md transition-colors ${activeObject.fontStyle === 'italic' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-secondary'}`}
                    title="Italic"
                  >
                    <Italic className="w-4 h-4" />
                  </button>
                </div>
                
                <div className="w-px h-6 bg-border/50 shrink-0" />

                <div className="flex items-center space-x-2 shrink-0">
                  <ALargeSmall className="w-4 h-4 text-muted-foreground" />
                  <input 
                    type="range" 
                    value={activeObject.fontSize || 16} 
                    onChange={(e) => updateActiveText('fontSize', parseInt(e.target.value, 10))}
                    className="w-16 sm:w-20 h-1 bg-secondary rounded-lg appearance-none cursor-pointer accent-primary"
                    min="8" max="150"
                  />
                  <span className="text-xs font-medium text-muted-foreground w-5 text-right font-mono">{Math.round(activeObject.fontSize || 16)}</span>
                </div>
                
                <div className="w-px h-6 bg-border/50 shrink-0" />
                
                <div className="flex items-center space-x-2">
                  <Type className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <input 
                    type="color" 
                    value={activeObject.fill || "#ffffff"} 
                    onChange={(e) => updateActiveText('fill', e.target.value)}
                    className="w-6 h-6 outline-none bg-transparent rounded-full cursor-pointer overflow-hidden p-0 border-0"
                    title="Font Color"
                  />
                </div>
                
                <div className="w-px h-6 bg-border/50" />
                
                <div className="flex items-center space-x-2">
                  <PaintBucket className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                  <input 
                    type="color" 
                    value={activeObject.backgroundColor ? activeObject.backgroundColor.substring(0,7) : "#000000"} 
                    onChange={(e) => updateActiveText('backgroundColor', e.target.value + 'AA')}
                    className="w-6 h-6 outline-none bg-transparent rounded-full cursor-pointer overflow-hidden p-0 border-0"
                    title="Background Color"
                  />
                </div>
              </motion.div>
            )}

            {/* Canvas wrapper defining bounds */}
            <div 
              ref={canvasContainerRef}
              className="relative shadow-2xl rounded-lg flex items-center justify-center shrink-0"
              style={{
                width: '100%',
                height: '100%',
                overflow: 'auto', // Allow scrolling natively inside canvas container if scaled
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: '#18181b', // matching background block
                touchAction: 'none'
              }}
            >
              {/* Note: Fabric visually sets style width/height. We wrap in a constrained box to auto-scale via CSS. */}
              <style dangerouslySetInnerHTML={{__html: `
                .canvas-container {
                  max-width: 100%;
                  height: auto !important;
                }
                .canvas-container canvas {
                  max-width: 100% !important;
                  height: auto !important;
                }
              `}} />
              <canvas ref={canvasRef} />
              
              {/* Overlay for clearing image */}
              <div className="absolute top-4 right-4 z-40">
                <button
                  onClick={handleClear}
                  className="bg-destructive/90 text-destructive-foreground p-3 rounded-full hover:bg-destructive hover:scale-110 transition-all shadow-lg backdrop-blur"
                  title="Remove image"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="upload-zone"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => !isLoading && fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`
              relative w-full h-full max-w-2xl flex flex-col items-center justify-center text-center 
              border-2 border-dashed rounded-2xl transition-all duration-300
              ${isDragging ? "border-primary bg-primary/5 scale-[1.02]" : "border-border/60 bg-secondary/20 hover:border-primary/50 hover:bg-secondary/40"}
              ${isLoading ? "pointer-events-none opacity-80 border-primary" : "cursor-pointer"}
            `}
          >
            {isLoading ? (
              <div className="flex flex-col items-center space-y-6 w-full max-w-xs">
                <div className="relative">
                  <Loader2 className="w-16 h-16 text-primary animate-spin" />
                  <div className="absolute inset-0 flex items-center justify-center text-xs font-bold text-foreground">
                    {loadingProgress}%
                  </div>
                </div>
                <div className="space-y-2 w-full">
                  <h4 className="font-semibold text-lg text-foreground">{loadingStatus}</h4>
                  <div className="h-2 w-full bg-secondary rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-primary"
                      initial={{ width: 0 }}
                      animate={{ width: `${loadingProgress}%` }}
                      transition={{ ease: "linear", duration: 0.2 }}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground pt-1">Please wait while AI analyzes the text structure</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center p-6 space-y-4 pointer-events-none text-balance">
                <div className={`
                  w-16 h-16 rounded-3xl flex items-center justify-center transition-colors duration-300 shadow-sm
                  ${isDragging ? "bg-primary text-primary-foreground" : "bg-background border border-border text-muted-foreground shadow-sm group-hover:text-primary"}
                `}>
                  {isDragging ? <FileImage className="w-8 h-8" /> : <UploadCloud className="w-8 h-8" />}
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-bold text-xl text-foreground">
                    {isDragging ? "Drop your image here!" : "Click or drag to upload"}
                  </h4>
                  <p className="text-sm text-muted-foreground max-w-[280px]">
                    Supports standard high-resolution image formats: PNG, JPG, WebP 
                    <span className="block mt-1 opacity-70">(Max 10MB)</span>
                  </p>
                </div>

                {error && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }} 
                    animate={{ opacity: 1, y: 0 }} 
                    className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 px-4 py-2 rounded-lg mt-4"
                  >
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{error}</span>
                  </motion.div>
                )}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
